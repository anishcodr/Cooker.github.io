import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Upload, ArrowRight, ArrowLeft, X, Check, Copy, QrCode, Music, Image, Sliders, BookOpen, Layers, Scissors,
} from "lucide-react";
import { toast } from "sonner";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { extractPdfPages, processPdfPages, type PdfPage } from "@/lib/pdf-utils";
import { nanoid } from "nanoid";
import FlipbookViewer from "@/components/FlipbookViewer";
import { QRCodeSVG } from "qrcode.react";

interface WizardProps {
  onClose: () => void;
  onComplete: () => void;
}

const CreationWizard = ({ onClose, onComplete }: WizardProps) => {
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [pdfPages, setPdfPages] = useState<PdfPage[]>([]);
  const [parsingPdf, setParsingPdf] = useState(false);
  const [parseProgress, setParseProgress] = useState({ current: 0, total: 0 });
  const [title, setTitle] = useState("");

  // Settings
  const [curlThickness, setCurlThickness] = useState(5);
  const [cameraAngle, setCameraAngle] = useState(6);
  const [albumFormat, setAlbumFormat] = useState("auto");
  const [displayMode, setDisplayMode] = useState("single");
  const [splitSpreads, setSplitSpreads] = useState(false);
  const [coverSpreadReorder, setCoverSpreadReorder] = useState(false);
  const [processedPages, setProcessedPages] = useState<PdfPage[]>([]);

  // Studio branding
  const [studioName, setStudioName] = useState("");
  const [studioPhone, setStudioPhone] = useState("");

  // File uploads
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [watermarkFile, setWatermarkFile] = useState<File | null>(null);

  // Rendering state
  const [rendering, setRendering] = useState(false);
  const [renderProgress, setRenderProgress] = useState(0);

  // Done state
  const [done, setDone] = useState(false);
  const [shareLink, setShareLink] = useState("");

  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || file.type !== "application/pdf") {
      toast.error("Please select a valid PDF file");
      return;
    }
    setPdfFile(file);
    setTitle(file.name.replace(".pdf", ""));
    setParsingPdf(true);
    try {
      const pages = await extractPdfPages(file, 1.5, (current, total) => {
        setParseProgress({ current, total });
      });
      setPdfPages(pages);
      toast.success(`Parsed ${pages.length} pages successfully`);
    } catch (err) {
      toast.error("Failed to parse PDF. Please try another file.");
      setPdfFile(null);
    }
    setParsingPdf(false);
  }, []);

  // Re-process pages when split settings change
  useEffect(() => {
    if (pdfPages.length === 0) {
      setProcessedPages([]);
      return;
    }
    let cancelled = false;
    processPdfPages(pdfPages, splitSpreads, coverSpreadReorder).then((result) => {
      if (!cancelled) setProcessedPages(result);
    });
    return () => { cancelled = true; };
  }, [pdfPages, splitSpreads, coverSpreadReorder]);

  // Auto-switch to facing mode when splitting
  useEffect(() => {
    if (splitSpreads) setDisplayMode("facing");
  }, [splitSpreads]);

  const uploadFile = async (file: File, bucket: string): Promise<string | null> => {
    if (!user) return null;
    const ext = file.name.split(".").pop();
    const path = `${user.id}/${nanoid()}.${ext}`;
    const { error } = await supabase.storage.from(bucket).upload(path, file);
    if (error) {
      toast.error(`Upload failed: ${error.message}`);
      return null;
    }
    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    return data.publicUrl;
  };

  const handleSubmit = async () => {
    if (!user || !pdfFile) return;
    setRendering(true);
    setRenderProgress(0);

    try {
      // Simulate progress while uploading
      const progressInterval = setInterval(() => {
        setRenderProgress((p) => Math.min(p + Math.random() * 5 + 1, 85));
      }, 200);

      // Upload files in parallel
      const [pdfUrl, audioUrl, logoUrl, watermarkUrl] = await Promise.all([
        uploadFile(pdfFile, "pdfs"),
        audioFile ? uploadFile(audioFile, "audio") : Promise.resolve(null),
        logoFile ? uploadFile(logoFile, "branding") : Promise.resolve(null),
        watermarkFile ? uploadFile(watermarkFile, "branding") : Promise.resolve(null),
      ]);

      clearInterval(progressInterval);

      if (!pdfUrl) {
        toast.error("PDF upload failed");
        setRendering(false);
        return;
      }

      setRenderProgress(90);

      const shareLinkId = nanoid(12);

      const { error } = await supabase.from("albums").insert({
        user_id: user.id,
        title: title || "Untitled Album",
        pdf_url: pdfUrl,
        audio_url: audioUrl,
        logo_url: logoUrl,
        watermark_url: watermarkUrl,
        settings: { curl_thickness: curlThickness, camera_angle: cameraAngle, album_format: albumFormat, display_mode: displayMode, split_spreads: splitSpreads, cover_reorder: coverSpreadReorder },
        share_link_id: shareLinkId,
        studio_name: studioName || null,
        studio_phone: studioPhone || null,
      } as any);

      if (error) {
        toast.error(`Save failed: ${error.message}`);
        setRendering(false);
        return;
      }

      setRenderProgress(100);
      setShareLink(`${window.location.origin}/view/${shareLinkId}`);

      setTimeout(() => {
        setRendering(false);
        setDone(true);
      }, 600);
    } catch (err) {
      toast.error("Something went wrong. Please try again.");
      setRendering(false);
    }
  };

  const copyLink = () => {
    navigator.clipboard.writeText(shareLink);
    toast.success("Link copied to clipboard!");
  };

  if (rendering) {
    return (
      <Overlay onClose={() => {}}>
        <div className="text-center py-8">
          <div className="relative w-24 h-24 mx-auto mb-8">
            <svg className="w-24 h-24 -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--muted))" strokeWidth="4" />
              <circle
                cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--primary))" strokeWidth="4"
                strokeDasharray={264} strokeDashoffset={264 - (264 * Math.min(renderProgress, 100)) / 100}
                strokeLinecap="round" className="transition-all duration-200"
              />
            </svg>
            <span className="absolute inset-0 flex items-center justify-center text-lg font-serif text-primary">
              {Math.min(Math.round(renderProgress), 100)}%
            </span>
          </div>
          <h3 className="font-serif text-xl mb-2">Uploading & Processing</h3>
          <p className="text-muted-foreground text-sm mb-10">Saving your flipbook to the cloud...</p>
          <div className="border border-champagne\/20 rounded-lg px-6 py-4 bg-surface-elevated inline-block">
            <p className="text-muted-foreground text-xs tracking-[0.2em] uppercase mb-1">From the makers</p>
            <p className="text-champagne font-serif">KlickSync Studio</p>
            <p className="text-muted-foreground text-xs mt-1">Simplify your wedding billing</p>
          </div>
        </div>
      </Overlay>
    );
  }

  if (done) {
    return (
      <Overlay onClose={onClose}>
        <div className="text-center py-4">
          <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
            <Check className="w-7 h-7 text-primary" />
          </div>
          <h3 className="font-serif text-2xl mb-2">Your Flipbook is Ready!</h3>
          <p className="text-muted-foreground text-sm mb-10">Share it with your clients using the link or QR code below.</p>

          <div className="bg-foreground rounded-xl p-4 mx-auto mb-8 inline-block">
            <QRCodeSVG
              value={shareLink}
              size={160}
              bgColor="hsl(40, 20%, 92%)"
              fgColor="hsl(0, 0%, 7%)"
              level="M"
            />
          </div>

          <div className="flex items-center gap-2 bg-secondary rounded-lg p-2 mb-8 max-w-sm mx-auto">
            <Input readOnly value={shareLink} className="bg-transparent border-0 text-sm text-foreground" />
            <Button variant="ghost" size="icon" onClick={copyLink}>
              <Copy className="w-4 h-4" />
            </Button>
          </div>

          <Button variant="hero-outline" onClick={onComplete}>
            Back to Dashboard
          </Button>
        </div>
      </Overlay>
    );
  }

  return (
    <Overlay onClose={onClose}>
      {/* Step indicators */}
      <div className="flex items-center justify-center gap-2 mb-10">
        {[1, 2].map((s) => (
          <div key={s} className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-colors ${
              step >= s ? "gradient-champagne text-primary-foreground" : "bg-muted text-muted-foreground"
            }`}>
              {s}
            </div>
            {s < 2 && <div className={`w-12 h-px transition-colors ${step > s ? "bg-primary" : "bg-muted"}`} />}
          </div>
        ))}
      </div>

      {step === 1 && (
        <div>
          <h3 className="font-serif text-xl text-center mb-2">Upload Your Album</h3>
          <p className="text-muted-foreground text-sm text-center mb-4">
            Select your PDF album (12×36, 14×40, etc.)
          </p>

          <div>
            <label className="text-sm text-muted-foreground mb-1.5 block">Album Title</label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Priya & Arjun — Dec 2025"
              className="bg-secondary border-border focus:border-primary mb-6"
            />
          </div>

          {/* Album Format & Display Mode */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <label className="text-sm text-muted-foreground mb-1.5 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" /> Album Format
              </label>
              <Select value={albumFormat} onValueChange={setAlbumFormat}>
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Auto-detect</SelectItem>
                  <SelectItem value="12x36">12×36 Spread</SelectItem>
                  <SelectItem value="14x40">14×40 Spread</SelectItem>
                  <SelectItem value="a4">Standard A4</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-1.5 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" /> Display Mode
              </label>
              <Select value={displayMode} onValueChange={setDisplayMode}>
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="single">Single Page (Panoramic)</SelectItem>
                  <SelectItem value="facing">Two-Page Facing</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Page Formatting */}
          <div className="mb-6 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm text-muted-foreground flex items-center gap-1.5">
                <Scissors className="w-3.5 h-3.5" /> Split Wide Spreads (12×36 → 12×18)
              </label>
              <Switch checked={splitSpreads} onCheckedChange={setSplitSpreads} />
            </div>
            {splitSpreads && (
              <label className="flex items-center gap-2 pl-5 cursor-pointer">
                <Checkbox
                  checked={coverSpreadReorder}
                  onCheckedChange={(v) => setCoverSpreadReorder(v === true)}
                />
                <span className="text-sm text-muted-foreground">
                  First page is a full Cover Spread (auto-route back cover to end)
                </span>
              </label>
            )}
          </div>

          <label
            className="border-2 border-dashed border-border rounded-xl p-12 text-center cursor-pointer hover:border-primary/40 transition-colors group block"
          >
            <input
              type="file"
              accept="application/pdf"
              className="hidden"
              onChange={handleFileSelect}
            />
            {parsingPdf ? (
              <div>
                <div className="w-10 h-10 rounded-full border-2 border-muted mx-auto mb-3 relative">
                  <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-primary animate-spin" />
                </div>
                <p className="text-sm text-foreground font-medium">
                  Parsing page {parseProgress.current} of {parseProgress.total}...
                </p>
              </div>
            ) : pdfFile ? (
              <div>
                <Check className="w-10 h-10 text-primary mx-auto mb-3" />
                <p className="text-sm text-foreground font-medium">{pdfFile.name}</p>
                <p className="text-xs text-muted-foreground mt-1">{pdfPages.length} pages • Ready to proceed</p>
              </div>
            ) : (
              <div>
                <Upload className="w-10 h-10 text-muted-foreground mx-auto mb-3 group-hover:text-primary transition-colors" />
                <p className="text-sm text-muted-foreground">Click to select your PDF</p>
              </div>
            )}
          </label>

          {/* Preview */}
          {(processedPages.length > 0 ? processedPages : pdfPages).length > 0 && (
            <div className="mt-6 grid grid-cols-4 gap-2 max-h-32 overflow-hidden rounded-lg">
              {(processedPages.length > 0 ? processedPages : pdfPages).slice(0, 4).map((p, i) => (
                <img key={i} src={p.dataUrl} alt={`Page ${i + 1}`} className="w-full h-full object-cover rounded" />
              ))}
            </div>
          )}

          <div className="flex justify-end mt-8">
            <Button variant="hero" disabled={!pdfFile || parsingPdf} onClick={() => setStep(2)}>
              Next <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div>
          <h3 className="font-serif text-xl text-center mb-2">Customize & Brand</h3>
          <p className="text-muted-foreground text-sm text-center mb-8">
            Fine-tune the experience for your clients
          </p>

          <div className="space-y-6">
            <SettingRow icon={Sliders} label="Studio Name">
              <Input
                value={studioName}
                onChange={(e) => setStudioName(e.target.value)}
                placeholder="e.g. Lakshya Photography"
                className="bg-secondary border-border"
              />
            </SettingRow>
            <SettingRow icon={Sliders} label="Studio Phone">
              <Input
                value={studioPhone}
                onChange={(e) => setStudioPhone(e.target.value)}
                placeholder="+91 XXXXX XXXXX"
                className="bg-secondary border-border"
              />
            </SettingRow>
            <SettingRow icon={Sliders} label="3D Page Curl">
              <input
                type="range" min="1" max="10" value={curlThickness}
                onChange={(e) => setCurlThickness(Number(e.target.value))}
                className="w-full accent-[hsl(40,45%,65%)]"
              />
            </SettingRow>
            <SettingRow icon={Sliders} label="Camera Angle">
              <input
                type="range" min="1" max="10" value={cameraAngle}
                onChange={(e) => setCameraAngle(Number(e.target.value))}
                className="w-full accent-[hsl(40,45%,65%)]"
              />
            </SettingRow>
            <SettingRow icon={Music} label="Background Music">
              <FileButton accept="audio/*" file={audioFile} onFile={setAudioFile} />
            </SettingRow>
            <SettingRow icon={Image} label="Custom Logo">
              <FileButton accept="image/*" file={logoFile} onFile={setLogoFile} />
            </SettingRow>
            <SettingRow icon={Image} label="Watermark">
              <FileButton accept="image/*" file={watermarkFile} onFile={setWatermarkFile} />
            </SettingRow>
          </div>

          {/* Live preview */}
          {(processedPages.length > 0 ? processedPages : pdfPages).length > 0 && (() => {
            const viewPages = processedPages.length > 0 ? processedPages : pdfPages;
            return (
              <div className="mt-8 border border-border rounded-lg p-4 bg-background">
                <p className="text-xs text-muted-foreground mb-3 text-center">Live Preview</p>
                <FlipbookViewer
                  pages={viewPages.map((p) => p.dataUrl)}
                  pageWidth={viewPages[0]?.width}
                  pageHeight={viewPages[0]?.height}
                  settings={{ curl_thickness: curlThickness, camera_angle: cameraAngle, album_format: albumFormat, display_mode: displayMode }}
                  className="max-h-[300px]"
                />
              </div>
            );
          })()}

          <div className="flex justify-between mt-10">
            <Button variant="ghost" onClick={() => setStep(1)}>
              <ArrowLeft className="w-4 h-4" /> Back
            </Button>
            <Button variant="hero" onClick={handleSubmit}>
              Submit & Generate
            </Button>
          </div>
        </div>
      )}
    </Overlay>
  );
};

const Overlay = ({ children, onClose }: { children: React.ReactNode; onClose: () => void }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-surface-overlay backdrop-blur-sm overflow-y-auto py-8">
    <div
      className="w-full max-w-lg mx-4 bg-card border border-border rounded-xl p-8 shadow-2xl relative opacity-0 animate-fade-up"
      style={{ animationDelay: "0.05s" }}
    >
      {onClose.toString() !== "() => {}" && (
        <button onClick={onClose} className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors">
          <X className="w-5 h-5" />
        </button>
      )}
      {children}
    </div>
  </div>
);

const SettingRow = ({ icon: Icon, label, children }: { icon: any; label: string; children: React.ReactNode }) => (
  <div className="flex items-center gap-4">
    <Icon className="w-4 h-4 text-primary flex-shrink-0" />
    <span className="text-sm text-secondary-foreground w-40 flex-shrink-0">{label}</span>
    <div className="flex-1">{children}</div>
  </div>
);

const FileButton = ({
  accept,
  file,
  onFile,
}: {
  accept: string;
  file: File | null;
  onFile: (f: File | null) => void;
}) => (
  <label className="cursor-pointer">
    <input
      type="file"
      accept={accept}
      className="hidden"
      onChange={(e) => onFile(e.target.files?.[0] ?? null)}
    />
    <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md text-sm bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors">
      {file ? (
        <>
          <Check className="w-3 h-3 text-primary" />
          {file.name.slice(0, 20)}
        </>
      ) : (
        "Upload"
      )}
    </span>
  </label>
);

export default CreationWizard;
