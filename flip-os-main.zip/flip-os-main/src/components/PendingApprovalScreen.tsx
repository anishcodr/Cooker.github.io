import { useAuth } from "@/hooks/useAuth";
import ScrollReveal from "@/components/ScrollReveal";
import { Clock } from "lucide-react";

const PendingApprovalScreen = () => {
  const { profile, signOut } = useAuth();

  return (
    <div className="min-h-screen flex items-center justify-center section-padding py-16">
      <ScrollReveal>
        <div className="max-w-md w-full text-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
            <Clock className="w-8 h-8 text-primary" />
          </div>
          <h1 className="font-serif text-2xl mb-3">Awaiting Admin Approval</h1>
          {profile?.order_id && (
            <p className="text-muted-foreground text-sm mb-2">
              Order ID: <span className="font-mono text-foreground">{profile.order_id}</span>
            </p>
          )}
          <p className="text-muted-foreground text-sm mb-8">
            Your payment is being reviewed. You'll get full access once approved.
          </p>
          <button
            onClick={signOut}
            className="text-sm text-muted-foreground hover:text-foreground underline underline-offset-4 transition-colors"
          >
            Sign out
          </button>
        </div>
      </ScrollReveal>
    </div>
  );
};

export default PendingApprovalScreen;
