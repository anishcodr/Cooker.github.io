import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Plus, LogOut, ExternalLink, Trash2 } from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import ScrollReveal from "@/components/ScrollReveal";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

interface Album {
  id: string;
  title: string;
  share_link_id: string;
  created_at: string;
  pdf_url: string;
  audio_url: string | null;
  logo_url: string | null;
  watermark_url: string | null;
  settings: { curl_thickness?: number; camera_angle?: number };
}

interface DashboardProps {
  onCreateNew: () => void;
  onLogout: () => void;
}

/** Extract storage path from a full Supabase public URL */
const extractStoragePath = (url: string, bucket: string): string | null => {
  const marker = `/storage/v1/object/public/${bucket}/`;
  const idx = url.indexOf(marker);
  if (idx === -1) return null;
  return url.substring(idx + marker.length);
};

const Dashboard = ({ onCreateNew, onLogout }: DashboardProps) => {
  const { user, profile, signOut } = useAuth();
  const [albums, setAlbums] = useState<Album[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState<string | null>(null);

  useEffect(() => {
    const fetchAlbums = async () => {
      if (!user) return;
      const { data } = await supabase
        .from("albums")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      if (data) setAlbums(data as unknown as Album[]);
      setLoading(false);
    };
    fetchAlbums();
  }, [user]);

  const handleLogout = async () => {
    await signOut();
    onLogout();
  };

  const handleDelete = async (album: Album) => {
    setDeleting(album.id);
    try {
      // Clean up storage files
      const filesToDelete: { bucket: string; path: string }[] = [];

      const urlMap: { url: string | null; bucket: string }[] = [
        { url: album.pdf_url, bucket: "pdfs" },
        { url: album.audio_url, bucket: "audio" },
        { url: album.logo_url, bucket: "branding" },
        { url: album.watermark_url, bucket: "branding" },
      ];

      for (const { url, bucket } of urlMap) {
        if (url) {
          const path = extractStoragePath(url, bucket);
          if (path) filesToDelete.push({ bucket, path });
        }
      }

      // Delete files from storage (best effort)
      for (const { bucket, path } of filesToDelete) {
        await supabase.storage.from(bucket).remove([path]);
      }

      // Delete album row
      const { error } = await supabase.from("albums").delete().eq("id", album.id);
      if (error) {
        toast.error("Failed to delete album");
        return;
      }

      setAlbums((prev) => prev.filter((a) => a.id !== album.id));
      toast.success("Album deleted successfully");
    } catch {
      toast.error("Something went wrong");
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="min-h-screen">
      <header className="section-padding py-5 border-b border-border flex items-center justify-between">
        <div className="font-serif text-2xl tracking-tight">
          <span className="gradient-champagne-text">Flip</span>
          <span className="text-foreground">OS</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm text-muted-foreground hidden sm:block">
            Welcome, {profile?.full_name || "User"}
          </span>
          <button onClick={handleLogout} className="text-muted-foreground hover:text-foreground transition-colors">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      <main className="section-padding py-12 max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h1 className="text-2xl md:text-3xl font-serif">Your Albums</h1>
            <p className="text-muted-foreground text-sm mt-1">{albums.length} flipbooks created</p>
          </div>
          <Button variant="hero" onClick={onCreateNew}>
            <Plus className="w-4 h-4" />
            Create New Album
          </Button>
        </div>

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-card border border-border rounded-xl overflow-hidden animate-pulse">
                <div className="aspect-[4/3] bg-surface-elevated" />
                <div className="p-5 space-y-2">
                  <div className="h-4 bg-muted rounded w-3/4" />
                  <div className="h-3 bg-muted rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : albums.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-16 h-16 rounded-full bg-surface-elevated flex items-center justify-center mx-auto mb-6">
              <Plus className="w-7 h-7 text-muted-foreground" />
            </div>
            <h3 className="font-serif text-xl mb-2">No Albums Yet</h3>
            <p className="text-muted-foreground text-sm mb-8">Create your first cinematic flipbook</p>
            <Button variant="hero" onClick={onCreateNew}>
              Create Your First Album
            </Button>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {albums.map((album, i) => (
              <ScrollReveal key={album.id} delay={i * 80}>
                <div className="group bg-card border border-border rounded-xl overflow-hidden hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5">
                  <div className="aspect-[4/3] bg-surface-elevated flex items-center justify-center relative">
                    <div className="text-center">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-2">
                        <span className="text-primary font-serif text-lg">
                          {new Date(album.created_at).getDate()}
                        </span>
                      </div>
                      <p className="text-muted-foreground text-xs">
                        {new Date(album.created_at).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}
                      </p>
                    </div>
                  </div>
                  <div className="p-5 flex items-start justify-between">
                    <div>
                      <h3 className="font-serif text-sm mb-1 group-hover:text-primary transition-colors">
                        {album.title}
                      </h3>
                      <p className="text-muted-foreground text-xs">Click to view flipbook</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <a
                        href={`/view/${album.share_link_id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-muted-foreground hover:text-primary transition-colors p-1"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <button
                            className="text-muted-foreground hover:text-destructive transition-colors p-1"
                            disabled={deleting === album.id}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Album</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete "{album.title}"? This will break the public link for your clients and permanently remove all associated files.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDelete(album)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Dashboard;
