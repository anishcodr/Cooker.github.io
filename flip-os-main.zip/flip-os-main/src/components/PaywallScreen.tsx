import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import ScrollReveal from "@/components/ScrollReveal";

const benefits = [
  "Unlimited flipbook creations",
  "All album formats (12×36, 14×40, A4, A5)",
  "Custom branding & watermarks",
  "Background music & voiceover",
  "QR code & link sharing",
  "Priority rendering",
];

const PaywallScreen = ({ onSubscribe }: { onSubscribe: () => void }) => {

  return (
    <div className="min-h-screen flex items-center justify-center section-padding py-16">
      <div className="max-w-lg w-full">
        <ScrollReveal>
          <div className="text-center mb-12">
            <p className="text-xs tracking-[0.3em] uppercase text-muted-foreground mb-4">
              One Plan. Everything Included.
            </p>
            <h1 className="text-3xl md:text-4xl font-serif tracking-tight">
              Unlock <span className="gradient-champagne-text">FlipOS Pro</span>
            </h1>
          </div>
        </ScrollReveal>

        <ScrollReveal delay={100}>
          <div className="bg-card border border-primary/20 rounded-xl p-8 shadow-xl shadow-primary/5">
            <div className="text-center mb-8">
              <p className="text-sm text-muted-foreground mb-2">Pro Photographer Plan</p>
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-5xl font-serif gradient-champagne-text">₹999</span>
                <span className="text-muted-foreground text-sm">/year</span>
              </div>
            </div>

            <div className="space-y-3 mb-8">
              {benefits.map((b) => (
                <div key={b} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-primary" />
                  </div>
                  <span className="text-sm text-secondary-foreground">{b}</span>
                </div>
              ))}
            </div>

            <Button
              variant="hero"
              size="lg"
              className="w-full"
              onClick={onSubscribe}
            >
              Subscribe Now
            </Button>
            <p className="text-center text-muted-foreground text-xs mt-4">
              Cancel anytime. No questions asked.
            </p>
          </div>
        </ScrollReveal>
      </div>
    </div>
  );
};

export default PaywallScreen;
