import { useEffect, useState } from "react";

const LoadingScreen = ({ onComplete }: { onComplete: () => void }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 400);
          return 100;
        }
        return prev + Math.random() * 12 + 3;
      });
    }, 120);
    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background">
      {/* Logo */}
      <div className="mb-12 opacity-0 animate-fade-in" style={{ animationDelay: "0.1s" }}>
        <h1 className="text-5xl md:text-6xl font-serif tracking-tight">
          <span className="gradient-champagne-text">Flip</span>
          <span className="text-foreground">OS</span>
        </h1>
      </div>

      {/* Spinner */}
      <div className="relative mb-12">
        <div className="w-12 h-12 rounded-full border-2 border-muted">
          <div
            className="absolute inset-0 rounded-full border-2 border-transparent border-t-primary animate-spin-slow"
          />
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-64 h-[2px] bg-muted rounded-full overflow-hidden mb-16">
        <div
          className="h-full gradient-champagne rounded-full transition-all duration-200 ease-out"
          style={{ width: `${Math.min(progress, 100)}%` }}
        />
      </div>

      {/* Marketing banner */}
      <div className="opacity-0 animate-fade-in text-center px-6" style={{ animationDelay: "0.5s" }}>
        <div className="inline-block border border-champagne\/20 rounded-lg px-8 py-4 bg-surface-elevated">
          <p className="text-muted-foreground text-xs tracking-[0.2em] uppercase mb-1">Powered by</p>
          <p className="text-champagne font-serif text-lg">KlickSync Studio</p>
          <p className="text-muted-foreground text-sm mt-1">The Ultimate Wedding Billing Management Program</p>
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;
