import { useRef, useEffect, useState, useCallback, useMemo } from "react";
import { PageFlip } from "page-flip";
import { Volume2, VolumeX } from "lucide-react";

interface FlipbookSettings {
  curl_thickness?: number;
  camera_angle?: number;
  album_format?: string;
  display_mode?: string;
}

interface FlipbookViewerProps {
  pages: string[];
  pageWidth?: number;
  pageHeight?: number;
  settings?: FlipbookSettings;
  audioUrl?: string | null;
  logoUrl?: string | null;
  watermarkUrl?: string | null;
  className?: string;
}

const ALBUM_FORMAT_RATIOS: Record<string, number> = {
  "12x36": 36 / 12, // 3:1
  "14x40": 40 / 14, // ~2.86:1
  "a4": 297 / 210,   // ~1.414:1
};

// splitPageInHalf is now imported from pdf-utils
import { splitPageInHalf } from "@/lib/pdf-utils";

const FlipbookViewer = ({
  pages,
  pageWidth,
  pageHeight,
  settings = {},
  audioUrl,
  logoUrl,
  watermarkUrl,
  className = "",
}: FlipbookViewerProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const flipBookRef = useRef<PageFlip | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const pageTurnAudioRef = useRef<HTMLAudioElement | null>(null);
  const [muted, setMuted] = useState(true);
  const [currentPage, setCurrentPage] = useState(0);
  const [processedPages, setProcessedPages] = useState<string[]>([]);
  const [processing, setProcessing] = useState(false);
  const mutedRef = useRef(muted);

  const displayMode = settings.display_mode || "single";
  const albumFormat = settings.album_format || "auto";

  // Compute effective aspect ratio
  const effectiveAspect = useMemo(() => {
    let aspect = (pageWidth && pageHeight) ? pageWidth / pageHeight : 4 / 3;

    // Override with album format if not auto
    if (albumFormat !== "auto" && ALBUM_FORMAT_RATIOS[albumFormat]) {
      aspect = ALBUM_FORMAT_RATIOS[albumFormat];
    }

    // For facing mode, each leaf is half the spread width
    if (displayMode === "facing") {
      aspect = aspect / 2;
    }

    return aspect;
  }, [pageWidth, pageHeight, albumFormat, displayMode]);

  // Compute PageFlip dimensions from aspect
  const flipDims = useMemo(() => {
    const baseWidth = 600;
    const h = Math.round(baseWidth / effectiveAspect);
    return { width: baseWidth, height: h };
  }, [effectiveAspect]);

  // Process pages for facing mode (split wide pages in half)
  useEffect(() => {
    if (displayMode !== "facing" || pages.length === 0) {
      setProcessedPages(pages);
      return;
    }

    let cancelled = false;
    setProcessing(true);

    (async () => {
      const result: string[] = [];
      for (const src of pages) {
        if (cancelled) return;
        try {
          const [left, right] = await splitPageInHalf(src);
          result.push(left, right);
        } catch {
          result.push(src); // fallback: use original
        }
      }
      if (!cancelled) {
        setProcessedPages(result);
        setProcessing(false);
      }
    })();

    return () => { cancelled = true; };
  }, [pages, displayMode]);

  const initFlipbook = useCallback(() => {
    if (!containerRef.current || processedPages.length === 0 || processing) return;

    if (flipBookRef.current) {
      flipBookRef.current.destroy();
      flipBookRef.current = null;
    }

    containerRef.current.innerHTML = "";

    const pageElements: HTMLElement[] = processedPages.map((src, i) => {
      const div = document.createElement("div");
      div.className = "flipbook-page";
      div.style.cssText = "background-size:contain;background-position:center;overflow:hidden;position:relative;";
      const img = document.createElement("img");
      img.src = src;
      img.alt = `Page ${i + 1}`;
      img.style.cssText = "width:100%;height:100%;object-fit:contain;";
      div.appendChild(img);

      if (watermarkUrl) {
        const wm = document.createElement("img");
        wm.src = watermarkUrl;
        wm.style.cssText =
          "position:absolute;bottom:8px;right:8px;width:60px;height:60px;opacity:0.4;pointer-events:none;";
        div.appendChild(wm);
      }
      return div;
    });

    pageElements.forEach((el) => containerRef.current!.appendChild(el));

    const flap = settings.curl_thickness ?? 5;

    // Responsive min/max based on aspect
    const isWide = effectiveAspect > 1.5;

    const flipBook = new PageFlip(containerRef.current, {
      width: flipDims.width,
      height: flipDims.height,
      size: "stretch",
      minWidth: isWide ? 320 : 280,
      maxWidth: isWide ? 1600 : 1200,
      minHeight: isWide ? 150 : 400,
      maxHeight: isWide ? 900 : 1600,
      showCover: true,
      maxShadowOpacity: Math.min(0.8, flap * 15 / 100),
      flippingTime: 1200 + (10 - (settings.camera_angle ?? 6)) * 80,
      useMouseEvents: true,
      swipeDistance: 15,
      drawShadow: true,
      autoSize: true,
      mobileScrollSupport: true,
      showPageCorners: true,
      disableFlipByClick: false,
      startZIndex: 15,
    });

    flipBook.loadFromHTML(pageElements);

    flipBook.on("flip", (e: { data: number }) => {
      setCurrentPage(e.data);
      // Play page-turn sound if not muted
      if (!mutedRef.current && pageTurnAudioRef.current) {
        pageTurnAudioRef.current.currentTime = 0;
        pageTurnAudioRef.current.play().catch(() => {});
      }
    });

    flipBookRef.current = flipBook;
  }, [processedPages, processing, settings.curl_thickness, settings.camera_angle, watermarkUrl, flipDims, effectiveAspect]);

  useEffect(() => {
    initFlipbook();
    return () => {
      flipBookRef.current?.destroy();
    };
  }, [initFlipbook]);

  const toggleMute = () => {
    const newMuted = !muted;
    setMuted(newMuted);
    mutedRef.current = newMuted;
    if (audioRef.current) {
      if (!newMuted) {
        audioRef.current.play().catch(() => {});
        audioRef.current.muted = false;
      } else {
        audioRef.current.muted = true;
      }
    }
  };

  const totalPages = processedPages.length;

  return (
    <div className={`relative flex flex-col items-center ${className}`}>
      {logoUrl && (
        <div className="absolute top-4 left-4 z-10">
          <img
            src={logoUrl}
            alt="Studio logo"
            className="h-10 w-auto object-contain opacity-80"
          />
        </div>
      )}

      <div
        ref={containerRef}
        className="w-full max-w-5xl"
        style={{
          aspectRatio: `${effectiveAspect}`,
          perspective: `${800 + (settings.camera_angle ?? 6) * 100}px`,
          transformStyle: "preserve-3d",
        }}
      />

      <div className="mt-4 text-muted-foreground text-sm">
        Page {currentPage + 1} of {totalPages}
      </div>

      {/* Page-turn sound (always present) */}
      <audio ref={pageTurnAudioRef} src="/sounds/page-turn.mp3" preload="auto" />

      {/* Background music (optional) */}
      {audioUrl && (
        <audio ref={audioRef} src={audioUrl} loop muted preload="auto" />
      )}

      {/* Always-visible mute button */}
      <button
        onClick={toggleMute}
        className="absolute bottom-4 right-4 z-10 w-10 h-10 rounded-full bg-card/80 backdrop-blur-sm border border-border flex items-center justify-center text-foreground hover:bg-card transition-colors"
      >
        {muted ? (
          <VolumeX className="w-4 h-4" />
        ) : (
          <Volume2 className="w-4 h-4" />
        )}
      </button>
    </div>
  );
};

export default FlipbookViewer;
