import { Button } from "@/components/ui/button";
import ScrollReveal from "@/components/ScrollReveal";
import {
  BookOpen, Layers, Camera, Music, Image, Share2,
  Upload, Settings, Sparkles
} from "lucide-react";

const HeroSection = ({ onGetStarted }: { onGetStarted: () => void }) => (
  <section className="relative min-h-screen flex items-center section-padding pt-32 pb-24 overflow-hidden">
    {/* Subtle radial glow */}
    <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full opacity-[0.07]"
      style={{ background: "radial-gradient(circle, hsl(40 45% 65%), transparent 70%)" }} />

    <div className="relative z-10 max-w-5xl mx-auto text-center">
      <ScrollReveal>
        <p className="text-xs tracking-[0.3em] uppercase text-muted-foreground mb-6">
          For Professional Wedding Photographers
        </p>
      </ScrollReveal>
      <ScrollReveal delay={100}>
        <h1 className="text-4xl sm:text-5xl md:text-7xl font-serif leading-[1.05] tracking-tight mb-8"
          style={{ textWrap: "balance" }}>
          Cinematic 3D Wedding Albums{" "}
          <span className="gradient-champagne-text">That Captivate</span>
        </h1>
      </ScrollReveal>
      <ScrollReveal delay={200}>
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-12 leading-relaxed"
          style={{ textWrap: "pretty" }}>
          Transform your static 12×36 and 14×40 PDFs into immersive, interactive flipbooks
          with realistic page-turn effects, background music, and custom branding.
        </p>
      </ScrollReveal>
      <ScrollReveal delay={300}>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button variant="hero" size="xl" onClick={onGetStarted}>
            Create Your Flipbook
          </Button>
          <Button variant="hero-outline" size="xl">
            Watch Demo
          </Button>
        </div>
      </ScrollReveal>
    </div>
  </section>
);

const DemoSection = () => (
  <section className="section-padding py-24">
    <div className="max-w-5xl mx-auto">
      <ScrollReveal>
        <div className="aspect-video rounded-xl border border-border bg-surface-elevated flex items-center justify-center overflow-hidden relative">
          <div className="absolute inset-0 opacity-5"
            style={{ background: "radial-gradient(circle at 30% 40%, hsl(40 45% 65%), transparent 60%)" }} />
          <div className="text-center relative z-10">
            <BookOpen className="w-16 h-16 text-primary mx-auto mb-4 opacity-60" />
            <p className="text-muted-foreground text-sm">Interactive 3D Flipbook Preview</p>
            <p className="text-muted-foreground/60 text-xs mt-1">Demo coming soon</p>
          </div>
        </div>
      </ScrollReveal>
    </div>
  </section>
);

const features = [
  {
    icon: Layers,
    title: "Realistic 3D Page Turns",
    desc: "Adjustable curl thickness and page weight for a lifelike reading experience.",
  },
  {
    icon: Camera,
    title: "Dynamic Camera Angles",
    desc: "Multiple perspective views that add cinematic depth to every page flip.",
  },
  {
    icon: Image,
    title: "Branding Controls",
    desc: "Add your logo, watermark, and custom colors to match your studio's identity.",
  },
  {
    icon: Music,
    title: "Audio Integration",
    desc: "Background music and page-turn sound effects for a complete sensory experience.",
  },
  {
    icon: BookOpen,
    title: "Multiple Formats",
    desc: "Full support for 12×36, 14×40, A4, and A5 album dimensions.",
  },
  {
    icon: Share2,
    title: "Instant Web Sharing",
    desc: "Generate a shareable link and QR code — no downloads needed.",
  },
];

const FeaturesSection = () => (
  <section className="section-padding py-32">
    <div className="max-w-6xl mx-auto">
      <ScrollReveal>
        <p className="text-xs tracking-[0.3em] uppercase text-muted-foreground text-center mb-4">
          Everything You Need
        </p>
        <h2 className="text-3xl md:text-5xl font-serif text-center mb-20 tracking-tight">
          Crafted for <span className="gradient-champagne-text">Professionals</span>
        </h2>
      </ScrollReveal>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((f, i) => (
          <ScrollReveal key={f.title} delay={i * 80}>
            <div className="group p-8 rounded-xl bg-surface-elevated border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 h-full">
              <f.icon className="w-8 h-8 text-primary mb-5 transition-transform duration-300 group-hover:scale-105" />
              <h3 className="text-lg font-serif mb-3 text-foreground">{f.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{f.desc}</p>
            </div>
          </ScrollReveal>
        ))}
      </div>
    </div>
  </section>
);

const steps = [
  { icon: Upload, label: "Upload", desc: "Drop your album PDF into FlipOS." },
  { icon: Settings, label: "Customize", desc: "Add branding, music, and effects." },
  { icon: Sparkles, label: "Share", desc: "Get a link and QR code instantly." },
];

const HowItWorksSection = () => (
  <section className="section-padding py-32">
    <div className="max-w-4xl mx-auto">
      <ScrollReveal>
        <h2 className="text-3xl md:text-5xl font-serif text-center mb-20 tracking-tight">
          Three Steps to <span className="gradient-champagne-text">Stunning</span>
        </h2>
      </ScrollReveal>
      <div className="grid md:grid-cols-3 gap-12 md:gap-8">
        {steps.map((s, i) => (
          <ScrollReveal key={s.label} delay={i * 120}>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full border border-primary/30 flex items-center justify-center mx-auto mb-6 bg-surface-elevated">
                <s.icon className="w-7 h-7 text-primary" />
              </div>
              <p className="text-xs tracking-[0.2em] uppercase text-primary mb-2">
                Step {i + 1}
              </p>
              <h3 className="text-xl font-serif mb-3">{s.label}</h3>
              <p className="text-muted-foreground text-sm">{s.desc}</p>
            </div>
          </ScrollReveal>
        ))}
      </div>
    </div>
  </section>
);

const FinalCTA = ({ onGetStarted }: { onGetStarted: () => void }) => (
  <section className="section-padding py-32">
    <div className="max-w-3xl mx-auto text-center">
      <ScrollReveal>
        <h2 className="text-3xl md:text-5xl font-serif mb-6 tracking-tight">
          Start Impressing Your Clients{" "}
          <span className="gradient-champagne-text">Today</span>
        </h2>
        <p className="text-muted-foreground text-lg mb-12 max-w-xl mx-auto" style={{ textWrap: "pretty" }}>
          Join professional photographers who deliver unforgettable album experiences.
        </p>
        <Button variant="hero" size="xl" onClick={onGetStarted}>
          Create Your Flipbook
        </Button>
      </ScrollReveal>
    </div>
  </section>
);

const Footer = () => (
  <footer className="section-padding py-12 border-t border-border">
    <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
      <div className="font-serif text-xl">
        <span className="gradient-champagne-text">Flip</span>
        <span className="text-foreground">OS</span>
      </div>
      <p className="text-muted-foreground text-sm">
        © 2026 FlipOS. A product by KlickSync Studio.
      </p>
    </div>
  </footer>
);

const LandingPage = ({ onGetStarted }: { onGetStarted: () => void }) => (
  <div className="min-h-screen">
    {/* Nav */}
    <nav className="fixed top-0 left-0 right-0 z-40 section-padding py-5 backdrop-blur-md bg-background/80 border-b border-border/50">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="font-serif text-2xl tracking-tight">
          <span className="gradient-champagne-text">Flip</span>
          <span className="text-foreground">OS</span>
        </div>
        <Button variant="hero" size="sm" onClick={onGetStarted}>
          Get Started
        </Button>
      </div>
    </nav>

    <HeroSection onGetStarted={onGetStarted} />
    <DemoSection />
    <FeaturesSection />
    <HowItWorksSection />
    <FinalCTA onGetStarted={onGetStarted} />
    <Footer />
  </div>
);

export default LandingPage;
