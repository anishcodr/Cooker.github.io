import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Check, Upload } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { nanoid } from "nanoid";
import { toast } from "sonner";
import ScrollReveal from "@/components/ScrollReveal";

interface PaymentPageProps {
  onSuccess: () => void;
}

const PaymentPage = ({ onSuccess }: PaymentPageProps) => {
  const { user, profile, refreshProfile } = useAuth();
  const isRenewal = profile?.subscription_status === "expired" || 
    (profile?.subscription_expires_at && new Date(profile.subscription_expires_at) < new Date());
  const [orderId] = useState(() => `ORD-${nanoid(5).toUpperCase()}`);
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState(user?.email || "");
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !screenshot) {
      toast.error("Please fill all fields and upload a screenshot");
      return;
    }
    if (!fullName.trim() || !phone.trim() || !email.trim()) {
      toast.error("Please fill all required fields");
      return;
    }

    setLoading(true);

    try {
      // Upload screenshot
      const ext = screenshot.name.split(".").pop();
      const path = `${user.id}/${nanoid()}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from("payment_screenshots")
        .upload(path, screenshot);

      if (uploadError) {
        toast.error(`Upload failed: ${uploadError.message}`);
        setLoading(false);
        return;
      }

      const { data: urlData } = supabase.storage
        .from("payment_screenshots")
        .getPublicUrl(path);

      // Update profile
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          phone_number: phone,
          payment_screenshot_url: urlData.publicUrl,
          order_id: orderId,
          subscription_status: "pending_approval",
          full_name: fullName,
        })
        .eq("id", user.id);

      if (updateError) {
        toast.error(`Submission failed: ${updateError.message}`);
        setLoading(false);
        return;
      }

      await refreshProfile();
      setSubmitted(true);
    } catch {
      toast.error("Something went wrong. Please try again.");
    }
    setLoading(false);
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center section-padding py-16">
        <ScrollReveal>
          <div className="max-w-md w-full text-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
              <Check className="w-8 h-8 text-primary" />
            </div>
            <h1 className="font-serif text-2xl mb-3">Payment Submitted</h1>
            <p className="text-muted-foreground text-sm mb-2">
              Order ID: <span className="font-mono text-foreground">{orderId}</span>
            </p>
            <p className="text-muted-foreground text-sm mb-8">
              Please wait for admin approval. You'll get access once your payment is verified.
            </p>
            <div className="border border-champagne/20 rounded-lg px-6 py-4 bg-surface-elevated inline-block">
              <p className="text-muted-foreground text-xs tracking-[0.2em] uppercase mb-1">From the makers</p>
              <p className="text-champagne font-serif">KlickSync Studio</p>
              <p className="text-muted-foreground text-xs mt-1">Simplify your wedding billing</p>
            </div>
          </div>
        </ScrollReveal>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center section-padding py-16">
      <div className="max-w-lg w-full">
        <ScrollReveal>
          <div className="text-center mb-10">
            <p className="text-xs tracking-[0.3em] uppercase text-muted-foreground mb-4">
              Complete Your Payment
            </p>
            <h1 className="text-3xl md:text-4xl font-serif tracking-tight mb-2">
              {isRenewal ? "Your 1-Year License has expired" : "Pro Photographer Plan"}
            </h1>
            {isRenewal && (
              <p className="text-primary text-sm font-medium mb-1">Renew for ₹999/Year to continue</p>
            )}
            <p className="text-muted-foreground text-sm">
              Order ID: <span className="font-mono text-foreground">{orderId}</span>
            </p>
          </div>
        </ScrollReveal>

        <ScrollReveal delay={100}>
          <div className="bg-card border border-primary/20 rounded-xl p-8 shadow-xl shadow-primary/5">
            {/* UPI Section */}
            <div className="text-center mb-8 pb-8 border-b border-border">
              <div className="w-48 h-48 bg-surface-elevated rounded-xl mx-auto mb-4 flex items-center justify-center border border-border">
                <QRCodeSVG
                  value="upi://pay?pa=reenarakesh670@okaxis&pn=FlipOS%20Subscription&am=999.00&cu=INR"
                  size={176}
                  bgColor="transparent"
                  fgColor="#d4af37"
                />
              </div>
              <p className="text-sm text-muted-foreground mb-1">UPI ID</p>
              <p className="font-mono text-foreground text-sm select-all">reenarakesh670@okaxis</p>
              <div className="mt-4 inline-flex items-baseline gap-1">
                <span className="text-4xl font-serif gradient-champagne-text">₹999</span>
                <span className="text-muted-foreground text-sm">/year</span>
              </div>
            </div>

            {/* Payment Verification Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="fullName">Full Name *</Label>
                <Input
                  id="fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Enter your full name"
                  className="bg-secondary border-border mt-1.5"
                  required
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 XXXXX XXXXX"
                  className="bg-secondary border-border mt-1.5"
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="bg-secondary border-border mt-1.5"
                  required
                />
              </div>
              <div>
                <Label>Payment Screenshot *</Label>
                <label className="mt-1.5 border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-primary/40 transition-colors block">
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => setScreenshot(e.target.files?.[0] ?? null)}
                  />
                  {screenshot ? (
                    <div className="flex items-center justify-center gap-2">
                      <Check className="w-4 h-4 text-primary" />
                      <span className="text-sm text-foreground">{screenshot.name}</span>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">Upload payment screenshot</p>
                    </div>
                  )}
                </label>
              </div>

              <Button
                type="submit"
                variant="hero"
                size="lg"
                className="w-full mt-6"
                disabled={loading}
              >
                {loading ? "Submitting..." : "Submit Payment Proof"}
              </Button>
            </form>
          </div>
        </ScrollReveal>
      </div>
    </div>
  );
};

export default PaymentPage;
