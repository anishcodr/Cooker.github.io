import * as pdfjsLib from "pdfjs-dist";

// Use CDN worker for pdfjs
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;

export interface PdfPage {
  pageNumber: number;
  dataUrl: string;
  width: number;
  height: number;
}

export async function extractPdfPages(
  file: File,
  scale = 2,
  onProgress?: (current: number, total: number) => void
): Promise<PdfPage[]> {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  const pages: PdfPage[] = [];

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const viewport = page.getViewport({ scale });

    const canvas = document.createElement("canvas");
    canvas.width = viewport.width;
    canvas.height = viewport.height;

    const ctx = canvas.getContext("2d")!;
    await page.render({ canvasContext: ctx, viewport }).promise;

    pages.push({
      pageNumber: i,
      dataUrl: canvas.toDataURL("image/jpeg", 0.85),
      width: viewport.width,
      height: viewport.height,
    });

    onProgress?.(i, pdf.numPages);
  }

  return pages;
}

/** Split a wide image into left and right halves, returning two data URLs */
export function splitPageInHalf(src: string): Promise<[string, string]> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const halfW = Math.floor(img.width / 2);
      const h = img.height;

      const makeHalf = (sx: number): string => {
        const c = document.createElement("canvas");
        c.width = halfW;
        c.height = h;
        const ctx = c.getContext("2d")!;
        ctx.drawImage(img, sx, 0, halfW, h, 0, 0, halfW, h);
        return c.toDataURL("image/jpeg", 0.85);
      };

      resolve([makeHalf(0), makeHalf(halfW)]);
    };
    img.onerror = reject;
    img.src = src;
  });
}

/**
 * Process PDF pages: split wide spreads and optionally reorder covers.
 * - splitSpreads: split pages where width > height into left/right halves
 * - coverReorder: treat first spread as cover (left half = front cover → page 1, right half = back cover → last page)
 */
export async function processPdfPages(
  pages: PdfPage[],
  splitSpreads: boolean,
  coverReorder: boolean
): Promise<PdfPage[]> {
  if (!splitSpreads || pages.length === 0) return pages;

  const result: PdfPage[] = [];
  let backCover: PdfPage | null = null;

  for (let i = 0; i < pages.length; i++) {
    const page = pages[i];
    const isWide = page.width > page.height;

    if (!isWide) {
      result.push(page);
      continue;
    }

    const [leftUrl, rightUrl] = await splitPageInHalf(page.dataUrl);
    const halfWidth = Math.floor(page.width / 2);

    const leftPage: PdfPage = { pageNumber: 0, dataUrl: leftUrl, width: halfWidth, height: page.height };
    const rightPage: PdfPage = { pageNumber: 0, dataUrl: rightUrl, width: halfWidth, height: page.height };

    if (i === 0 && coverReorder) {
      // Left half = Front Cover (first page), Right half = Back Cover (last page)
      result.push(leftPage);
      backCover = rightPage;
    } else {
      result.push(leftPage);
      result.push(rightPage);
    }
  }

  if (backCover) {
    result.push(backCover);
  }

  // Renumber pages
  result.forEach((p, idx) => { p.pageNumber = idx + 1; });

  return result;
}
