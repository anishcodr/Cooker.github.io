import { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { extractPdfPages } from "@/lib/pdf-utils";
import FlipbookViewer from "@/components/FlipbookViewer";
import { Maximize, Minimize } from "lucide-react";

interface AlbumSettings {
  curl_thickness?: number;
  camera_angle?: number;
  album_format?: string;
  display_mode?: string;
}

interface AlbumData {
  title: string;
  pdf_url: string;
  audio_url: string | null;
  logo_url: string | null;
  watermark_url: string | null;
  settings: AlbumSettings;
  studio_name: string | null;
  studio_phone: string | null;
}

const ViewerPage = () => {
  const { id } = useParams<{ id: string }>();
  const [album, setAlbum] = useState<AlbumData | null>(null);
  const [pages, setPages] = useState<string[]>([]);
  const [pageWidth, setPageWidth] = useState(0);
  const [pageHeight, setPageHeight] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loadingProgress, setLoadingProgress] = useState("");
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const fetchAlbum = async () => {
      if (!id) {
        setError("Invalid link");
        setLoading(false);
        return;
      }

      const { data, error: fetchError } = await supabase
        .from("albums")
        .select("*")
        .eq("share_link_id", id)
        .single();

      if (fetchError || !data) {
        setError("Album not found");
        setLoading(false);
        return;
      }

      const albumData = data as unknown as AlbumData;
      setAlbum(albumData);
      setLoadingProgress("Downloading PDF...");

      try {
        const response = await fetch(albumData.pdf_url);
        const blob = await response.blob();
        const file = new File([blob], "album.pdf", { type: "application/pdf" });

        setLoadingProgress("Rendering pages...");
        const pdfPages = await extractPdfPages(file, 2, (current, total) => {
          setLoadingProgress(`Rendering page ${current} of ${total}...`);
        });

        if (pdfPages.length > 0) {
          setPageWidth(pdfPages[0].width);
          setPageHeight(pdfPages[0].height);
        }

        setPages(pdfPages.map((p) => p.dataUrl));
      } catch {
        setError("Failed to load album");
      }

      setLoading(false);
    };

    fetchAlbum();
  }, [id]);

  // Fullscreen listener
  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", handler);
    return () => document.removeEventListener("fullscreenchange", handler);
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      document.documentElement.requestFullscreen();
    }
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background">
        <div className="relative mb-8">
          <div className="w-12 h-12 rounded-full border-2 border-muted">
            <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-primary animate-spin" />
          </div>
        </div>
        <p className="text-muted-foreground text-sm">{loadingProgress || "Loading album..."}</p>
      </div>
    );
  }

  if (error || !album) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background">
        <h1 className="font-serif text-2xl mb-2 text-foreground">{error || "Not Found"}</h1>
        <p className="text-muted-foreground text-sm">This album link may be invalid or expired.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="px-6 py-4 border-b border-border flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <div className="font-serif text-xl tracking-tight">
            <span className="gradient-champagne-text">Flip</span>
            <span className="text-foreground">OS</span>
          </div>
          {album.logo_url && (
            <img src={album.logo_url} alt="Studio logo" className="h-8 object-contain" />
          )}
          {album.studio_name && (
            <span className="text-sm text-muted-foreground font-serif hidden sm:block">
              {album.studio_name}
            </span>
          )}
        </div>
        <div className="flex items-center gap-4">
          <p className="text-sm text-muted-foreground font-serif hidden sm:block">{album.title}</p>
          <button
            onClick={toggleFullscreen}
            className="text-muted-foreground hover:text-foreground transition-colors p-1"
            title={isFullscreen ? "Exit fullscreen" : "Fullscreen"}
          >
            {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Flipbook */}
      <div className="flex-1 flex items-center justify-center p-4 md:p-8">
        <FlipbookViewer
          pages={pages}
          pageWidth={pageWidth}
          pageHeight={pageHeight}
          settings={album.settings}
          audioUrl={album.audio_url}
          logoUrl={album.logo_url}
          watermarkUrl={album.watermark_url}
          className="w-full max-w-5xl"
        />
      </div>

      {/* Footer marquee */}
      {album.studio_phone && (
        <footer className="border-t border-border bg-card py-2 overflow-hidden shrink-0">
          <div className="animate-marquee whitespace-nowrap text-sm text-muted-foreground">
            <span className="inline-block px-8">
              Book your shoot today! Call: {album.studio_phone}
            </span>
            <span className="inline-block px-8">
              📸 Premium Wedding Photography & Albums
            </span>
            <span className="inline-block px-8">
              Book your shoot today! Call: {album.studio_phone}
            </span>
            <span className="inline-block px-8">
              📸 Premium Wedding Photography & Albums
            </span>
          </div>
        </footer>
      )}
    </div>
  );
};

export default ViewerPage;
