import { useEffect, useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { Shield, CheckCircle, PauseCircle, Ban, ExternalLink, LogOut } from "lucide-react";

interface UserRow {
  id: string;
  full_name: string;
  phone_number: string | null;
  subscription_status: string;
  subscription_expires_at: string | null;
  payment_screenshot_url: string | null;
  order_id: string | null;
  email?: string;
}

const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  active: { label: "Active", variant: "default" },
  inactive: { label: "Inactive", variant: "secondary" },
  pending_approval: { label: "Pending", variant: "outline" },
  hold: { label: "On Hold", variant: "secondary" },
  blocked: { label: "Blocked", variant: "destructive" },
  expired: { label: "Expired", variant: "destructive" },
};

const AdminPage = () => {
  const { user, signOut } = useAuth();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setIsAdmin(false);
      setLoading(false);
      return;
    }

    const checkAdmin = async () => {
      const { data } = await supabase.rpc("has_role", {
        _user_id: user.id,
        _role: "admin",
      });
      setIsAdmin(!!data);

      if (data) {
        await fetchUsers();
      }
      setLoading(false);
    };

    checkAdmin();
  }, [user]);

  const fetchUsers = useCallback(async () => {
    const { data } = await supabase
      .from("profiles")
      .select("id, full_name, phone_number, subscription_status, subscription_expires_at, payment_screenshot_url, order_id")
      .order("created_at", { ascending: false });

    if (data) {
      setUsers(data as unknown as UserRow[]);
    }
  }, []);

  const updateStatus = async (targetUserId: string, newStatus: string) => {
    setActionLoading(targetUserId + newStatus);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error("Session expired");
        return;
      }

      const response = await supabase.functions.invoke("admin-update-user", {
        body: { target_user_id: targetUserId, new_status: newStatus },
      });

      if (response.error) {
        toast.error("Failed to update user");
        return;
      }

      toast.success(`User status updated to ${newStatus}`);
      await fetchUsers();
    } catch {
      toast.error("Something went wrong");
    } finally {
      setActionLoading(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-10 h-10 rounded-full border-2 border-muted relative">
          <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-primary animate-spin" />
        </div>
      </div>
    );
  }

  if (!user || !isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Shield className="w-12 h-12 text-destructive mx-auto mb-4" />
          <h1 className="font-serif text-2xl mb-2">Access Denied</h1>
          <p className="text-muted-foreground text-sm">You do not have admin privileges.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="section-padding py-5 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="font-serif text-2xl tracking-tight">
            <span className="gradient-champagne-text">Flip</span>
            <span className="text-foreground">OS</span>
          </div>
          <Badge variant="outline" className="text-xs">Admin</Badge>
        </div>
        <button onClick={() => signOut()} className="text-muted-foreground hover:text-foreground transition-colors">
          <LogOut className="w-4 h-4" />
        </button>
      </header>

      <main className="section-padding py-10 max-w-7xl mx-auto">
        <h1 className="font-serif text-2xl mb-8">User Management</h1>

        <div className="border border-border rounded-xl overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Order ID</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Expires</TableHead>
                <TableHead>Screenshot</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                    No users found
                  </TableCell>
                </TableRow>
              ) : (
                users.map((u) => {
                  const sc = statusConfig[u.subscription_status] || statusConfig.inactive;
                  return (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium">{u.full_name || "—"}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">{u.phone_number || "—"}</TableCell>
                      <TableCell className="text-muted-foreground text-xs font-mono">{u.order_id || "—"}</TableCell>
                      <TableCell>
                        <Badge variant={sc.variant}>{sc.label}</Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-xs">
                        {u.subscription_expires_at
                          ? new Date(u.subscription_expires_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
                          : "—"}
                      </TableCell>
                      <TableCell>
                        {u.payment_screenshot_url ? (
                          <a
                            href={u.payment_screenshot_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-primary text-sm hover:underline"
                          >
                            View <ExternalLink className="w-3 h-3" />
                          </a>
                        ) : (
                          <span className="text-muted-foreground text-sm">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs gap-1"
                            disabled={u.subscription_status === "active" || actionLoading === u.id + "active"}
                            onClick={() => updateStatus(u.id, "active")}
                          >
                            <CheckCircle className="w-3 h-3" /> Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs gap-1"
                            disabled={u.subscription_status === "hold" || actionLoading === u.id + "hold"}
                            onClick={() => updateStatus(u.id, "hold")}
                          >
                            <PauseCircle className="w-3 h-3" /> Hold
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            className="text-xs gap-1"
                            disabled={u.subscription_status === "blocked" || actionLoading === u.id + "blocked"}
                            onClick={() => updateStatus(u.id, "blocked")}
                          >
                            <Ban className="w-3 h-3" /> Block
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </main>
    </div>
  );
};

export default AdminPage;
