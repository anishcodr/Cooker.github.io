import { useState, useCallback, useEffect } from "react";
import LoadingScreen from "@/components/LoadingScreen";
import LandingPage from "@/components/LandingPage";
import AuthModal from "@/components/AuthModal";
import PaywallScreen from "@/components/PaywallScreen";
import PaymentPage from "@/components/PaymentPage";
import PendingApprovalScreen from "@/components/PendingApprovalScreen";
import Dashboard from "@/components/Dashboard";
import CreationWizard from "@/components/CreationWizard";
import { useAuth } from "@/hooks/useAuth";

type AppState = "loading" | "landing" | "auth" | "paywall" | "payment" | "pending" | "dashboard" | "wizard";

const Index = () => {
  const { user, profile, loading: authLoading } = useAuth();
  const [state, setState] = useState<AppState>("loading");

  const resolveState = useCallback((): AppState => {
    if (!user || !profile) return "landing";
    const s = profile.subscription_status;
    if (s === "blocked") return "landing";
    if (s === "pending_approval") return "pending";
    if (s === "hold") return "pending";
    if (s === "active") {
      // Check if subscription has expired
      if (profile.subscription_expires_at) {
        const expiresAt = new Date(profile.subscription_expires_at);
        if (expiresAt < new Date()) return "paywall";
      }
      return "dashboard";
    }
    if (s === "expired") return "paywall";
    return "paywall";
  }, [user, profile]);

  const handleLoadingComplete = useCallback(() => {
    if (authLoading) {
      setState("landing");
    } else {
      setState(resolveState());
    }
  }, [authLoading, resolveState]);

  useEffect(() => {
    if (state === "loading" || authLoading) return;

    if (user && profile) {
      // Always enforce DB status as source of truth
      const dbState = resolveState();
      if (state === "auth") {
        setState(dbState);
      } else if (state === "dashboard" || state === "wizard") {
        // If user refreshed but status changed, enforce it
        if (dbState !== "dashboard") {
          setState(dbState);
        }
      }
    } else if (!user && (state === "dashboard" || state === "wizard" || state === "paywall" || state === "payment" || state === "pending")) {
      setState("landing");
    }
  }, [user, profile, authLoading, state, resolveState]);

  const handleGetStarted = useCallback(() => setState("auth"), []);
  const handleLogout = useCallback(() => setState("landing"), []);

  return (
    <>
      {state === "loading" && <LoadingScreen onComplete={handleLoadingComplete} />}
      {state === "landing" && <LandingPage onGetStarted={handleGetStarted} />}
      {state === "auth" && (
        <>
          <LandingPage onGetStarted={handleGetStarted} />
          <AuthModal onClose={() => setState("landing")} />
        </>
      )}
      {state === "paywall" && <PaywallScreen onSubscribe={() => setState("payment")} />}
      {state === "payment" && <PaymentPage onSuccess={() => setState("pending")} />}
      {state === "pending" && <PendingApprovalScreen />}
      {state === "dashboard" && (
        <Dashboard onCreateNew={() => setState("wizard")} onLogout={handleLogout} />
      )}
      {state === "wizard" && (
        <>
          <Dashboard onCreateNew={() => {}} onLogout={handleLogout} />
          <CreationWizard onClose={() => setState("dashboard")} onComplete={() => setState("dashboard")} />
        </>
      )}
    </>
  );
};

export default Index;
