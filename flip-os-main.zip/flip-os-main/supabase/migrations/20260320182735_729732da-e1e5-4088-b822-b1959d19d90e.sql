
-- Fix Bug 1: Drop overly permissive SELECT policy
DROP POLICY IF EXISTS "Anyone can view albums by share link" ON public.albums;

-- Create a new anon-only SELECT policy for the public viewer
CREATE POLICY "Anon can view albums"
  ON public.albums FOR SELECT TO anon
  USING (true);

-- Add storage upload RLS policies for all buckets
-- Users can only upload to their own user_id/ folder
CREATE POLICY "Users can upload own files to pdfs"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'pdfs' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users can upload own files to audio"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'audio' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users can upload own files to branding"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'branding' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users can upload own files to payment_screenshots"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'payment_screenshots' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Public read for all buckets (needed for viewer)
CREATE POLICY "Public read access for all buckets"
  ON storage.objects FOR SELECT TO public
  USING (true);
