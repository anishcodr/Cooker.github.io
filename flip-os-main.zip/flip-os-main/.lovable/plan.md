

# Subscription Lifecycle & Storage Management

## Update 1: 365-Day License Tracking

### Database Migration
- Add `subscription_expires_at` (timestamptz, nullable) column to `profiles` table
- Add `expired` to the valid statuses in the edge function

### Edge Function Update (`admin-update-user/index.ts`)
- When `new_status === "active"`, also set `subscription_expires_at` to `NOW() + INTERVAL '365 days'`
- Accept the new `expired` status value

### Frontend Expiration Check (`Index.tsx` → `resolveState`)
- Add `subscription_expires_at` to the `Profile` interface in `useAuth.tsx`
- In `resolveState()`: if status is `active` but `subscription_expires_at` is in the past, treat as `"paywall"` (expired)
- Optionally auto-update status to `expired` via profile update

### Payment Page Renewal Messaging (`PaymentPage.tsx`)
- Accept an optional `isRenewal` prop (or check `profile.subscription_status === "expired"`)
- If expired, change heading to "Your 1-Year License has expired. Renew for ₹999/Year"

### Admin Table Update (`AdminPage.tsx`)
- Add `expired` to `statusConfig` with a distinct badge
- Display `subscription_expires_at` date in the table (new column)

---

## Update 2: Delete Album with Storage Cleanup

### Dashboard UI (`Dashboard.tsx`)
- Add a red `Trash2` icon button on each album card
- On click, show an `AlertDialog` confirmation: "Are you sure? This will break the public link for your clients."

### Deletion Logic (`Dashboard.tsx`)
- On confirm, extract file paths from the album's `pdf_url`, `audio_url`, `logo_url`, `watermark_url` fields
- Call `supabase.storage.from(bucket).remove([path])` for each non-null file URL (parse the path from the full URL)
- Delete the album row: `supabase.from("albums").delete().eq("id", album.id)`
- Remove from local state and show success toast

### Helper: Extract Storage Path
- Parse the storage file path from a full Supabase public URL (strip the base URL + `/storage/v1/object/public/{bucket}/` prefix)

---

## Files Changed

| File | Change |
|------|--------|
| Migration SQL | Add `subscription_expires_at` to profiles |
| `supabase/functions/admin-update-user/index.ts` | Set expiry on approve, accept `expired` status |
| `src/hooks/useAuth.tsx` | Add `subscription_expires_at` to Profile interface |
| `src/pages/Index.tsx` | Check expiration in `resolveState` |
| `src/components/PaymentPage.tsx` | Renewal messaging for expired users |
| `src/pages/AdminPage.tsx` | Show expiry date, add `expired` badge |
| `src/components/Dashboard.tsx` | Delete button + AlertDialog + storage cleanup |

